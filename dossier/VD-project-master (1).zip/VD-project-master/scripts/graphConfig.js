// Parameters
const width = 600;
const height = 600;
const padding = 20;
const margin = { top: 20, right: 0, bottom: 20, left: 30 };